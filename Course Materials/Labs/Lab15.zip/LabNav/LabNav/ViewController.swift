//
//  ViewController.swift
//  LabNav
//
//  Created by Bear Q Cahill on 1/16/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
//        if identifier == "segOneToTwo" {
//            return false
//        }
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segOneToTwo" {
            if let vc = segue.destination as? SecondViewController {
                vc.title = "\(Date())"
                vc.text = "X"
            }
        }
    }

}

