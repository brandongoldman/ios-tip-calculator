//
//  SecondViewController.swift
//  LabNav
//
//  Created by Bear Q Cahill on 1/16/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var lblSecond: UILabel!
    var text = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblSecond.text = self.text

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
