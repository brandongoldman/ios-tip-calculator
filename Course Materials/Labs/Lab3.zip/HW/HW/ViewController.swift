//
//  ViewController.swift
//  HW
//
//  Created by Bear Q Cahill on 12/23/19.
//  Copyright © 2019 Bear Cahill. All rights reserved.
//

import UIKit

class TipCalc {
    var tipPercentage = 0.15
    
    func calcTip(amount: Double) -> Double {
        return amount * tipPercentage
    }
}

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print (self.view.frame)
        let tc = TipCalc()
        let r = tc.calcTip(amount: 20.0)
        print (r)
        // Do any additional setup after loading the view.
    }


}

