//
//  ViewController.swift
//  LabHOF
//
//  Created by Bear Q Cahill on 1/16/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var names = ["Denton", "Mandeville", "Goteborg", "Bear", "Ventura"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        hofForeach()
        hofMap()
        hofFilter()
        hofCompactMap()
        hofReduce()
        closureType()
    }
    
    func hofForeach() {
        names.forEach({ (name) in
            print (name.count)
        })
    }
    
    func hofMap() {
        let lens : [Int] = names.map { (name) -> Int in
            return name.count
        }
        print (lens)
    }
    
    func hofFilter() {
        let longerNames = names.filter { (name) -> Bool in
            return name.count > 6
        }
        print (longerNames)
    }
    
    func hofCompactMap() {
        
        let longerLens : [Int] = names.compactMap { (name) -> Int? in
            return name.count > 6 ? name.count : nil
        }
        
        print (longerLens)
    }

    func hofReduce() {
        let oneVal = names.reduce("") { (ongoing, next) -> String in
            print ("---\nongoing: \(ongoing)\nNext: \(next)\nReturning: \(ongoing + next + " ")")
            return ongoing + next + " "
        }
        print (oneVal)
        
        let anotherVal = names.reduce(0) { (ongoing, next) -> Int in
            print ("---\nongoing: \(ongoing)\nNext: \(next)\nReturning: \(ongoing + next.count)")
            return ongoing + next.count
        }
        print (anotherVal)
    }
    
    func closureType() {
        let closureToPrint : (String)->Void = { (name:String) in
            print (name)
        }
        names.forEach(closureToPrint)
    }

}

