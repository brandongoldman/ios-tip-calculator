//
//  LabUTTests.swift
//  LabUTTests
//
//  Created by Bear Q Cahill on 1/16/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import XCTest
@testable import LabUT

class LabUTTests: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testOne() {
        let dbl = Double("1") ?? 0
        XCTAssertEqual(dbl, 1, "should be 1")
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
