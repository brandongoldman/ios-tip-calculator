//
//  ContentView.swift
//  LabSUI
//
//  Created by Bear Q Cahill on 1/31/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//



class TipCalc {
//    var tipPercentage = 0.15
//
//    init(tp : Double) {
//        tipPercentage = tp
//    }
    
    func calcTip(amount: Double, tipPercentage : Double = 0.15) -> Double {
        return amount * tipPercentage
    }
}


import SwiftUI

struct ContentView: View {
    
    @State private var billString = "0.00"
    @State private var billAmt = 0.00
    @State private var tipIndex = 0
    @State private var tip = 0.0
    let tipPercs = [0,1,2]
    
    var body: some View {
        
        // wrapper: tip percentage index
        let tipPercBinding = Binding<Int> (get: {
            // return wrapped value
            return self.tipIndex
        }, set: {
            // set value and update tip
            self.tipIndex = $0
            self.tip = TipCalc().calcTip(amount: self.billAmt,
                                         tipPercentage: Double(self.tipIndex) * 0.05 + 0.1)
        })
        
        // wrapper: binding called when value (text field) changes
        let billAmtBinding = Binding<String> (get: {
            // return the string value
            return self.billString
        }, set: {
            // update the string value and calculate the bill amount and tip
            self.billString = $0
            // only need to recalc the bill amount if they changed it (so only needed here)
            self.billAmt = Double(self.billString) ?? 0.00
            self.tip = TipCalc().calcTip(amount: self.billAmt,
                                         tipPercentage: Double(self.tipIndex) * 0.05 + 0.1)
        })

        // needs return b/c of code above
        return VStack {
            // bind to the string bill amount
            TextField("Enter Bill Amount", text: billAmtBinding)
            
            // based on values; updated when necessary
            // when tip updates, both of these will update
            Text("Tip: $\(tip)")
            Text("Total: $\(tip + billAmt)")

            // bind to Int binding
            Picker(selection: tipPercBinding, label: Text("Tip Percentage")) {
                ForEach(tipPercs, id:\.self){ v in
                    Text("\(Double(v) * 0.05 + 0.1)%").tag(v)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            
            Button(action: {
                print (self.$billString.wrappedValue)
                // not needed if we're going to calculate via bindings
//                let amt = Double(self.billString) ?? 0.00
//                self.tip = TipCalc().calcTip(amount: amt, tipPercentage: Double(self.tip) * 0.05 + 0.1)
                print (self.tip)
            }) {
                Text("Calculate")
            }
            
            Spacer()
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
