//
//  ViewController.swift
//  LabWebJS
//
//  Created by Bear Q Cahill on 1/22/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit
import WebKit

extension UIViewController: WKScriptMessageHandler {
    public func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
      if let messageBody = message.body as? String {
        print(messageBody)
      }
  }
}

class ViewController: UIViewController {

    var webView : WKWebView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        defineWebView()
        loadHTML()
    }
    
    func loadHTML() {
        guard let url = Bundle.main.url(forResource: "index", withExtension: "html") else { return }
        guard let html = try? String.init(contentsOf: url) else { return }
        webView?.loadHTMLString(html, baseURL: nil)
    }

    func defineWebView() {
        let wvConfig = WKWebViewConfiguration()
        let wvContentController = WKUserContentController()
                
        // WKUserScript allows JavaScript behavior to be injected at the start or end of document load.
        // Allows for web content to be manipulated in a safe and consistent way across page requests.
        let source = """
            document.body.style.background = "#711";
        """
        let userScript = WKUserScript(source: source,
                                      injectionTime: .atDocumentEnd,
                                      forMainFrameOnly: false)
        
        wvContentController.addUserScript(userScript)
        
        wvConfig.userContentController = wvContentController

        // Add self as message handler. Creates function to be called:
        // window.webkit.messageHandlers.<name parameter>.postMessage(<value>);
        wvContentController.add(self, name: "handleMsg")

        webView = WKWebView(frame: self.view.bounds, configuration: wvConfig)
        self.view.addSubview(webView!)

    }


}

