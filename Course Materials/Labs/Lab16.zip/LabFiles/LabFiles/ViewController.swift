//
//  ViewController.swift
//  LabFiles
//
//  Created by Bear Q Cahill on 1/16/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let path = NSTemporaryDirectory() + "test.txt"
        writeFile(text: "test", path: path)
        let origText = readFile(path: path)
        print (origText)
    }
    
    func writeFile(text: String, path: String) {
        print (path)
        let fileURL = URL.init(fileURLWithPath: path)
        guard let data = text.data(using: .utf8) else { return }
        try? data.write(to: fileURL)
    }
    
    func readFile(path: String) -> String {
        print (path)
        let fileURL = URL.init(fileURLWithPath: path)
        guard let data = try? Data(contentsOf: fileURL) else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }


}

