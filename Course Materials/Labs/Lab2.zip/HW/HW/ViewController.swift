//
//  ViewController.swift
//  HW
//
//  Created by Bear Q Cahill on 12/23/19.
//  Copyright © 2019 Bear Cahill. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print (self.view.frame)
        // Do any additional setup after loading the view.
    }


}

