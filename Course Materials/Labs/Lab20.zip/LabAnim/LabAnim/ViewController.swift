//
//  ViewController.swift
//  LabAnim
//
//  Created by Bear Q Cahill on 1/17/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController {

    @IBOutlet weak var vBox: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func handlePan(_ sender: UIPanGestureRecognizer) {
        let point = sender.location(in: self.view)
        UIView.animate(withDuration: 3.0) {
            self.vBox.center = point
            self.vBox.backgroundColor = UIColor.blue
            self.vBox.layer.cornerRadius = self.vBox.frame.size.height/2
        }
    }
    
}

