//
//  ViewController.swift
//  LabURL
//
//  Created by Bear Q Cahill on 1/16/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        fetchImage()
    }

    func fetchImage() {
        
        if let url = URL.init(string: "https://www.apple.com/ac/structured-data/images/knowledge_graph_logo.png?201606271147") {
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                DispatchQueue.main.async {
                    let iv = UIImageView.init(frame: self.view.bounds)
                    iv.image = UIImage.init(data: data!)
                    self.view.addSubview(iv)
                }
            }
            task.resume()
        }
        
    }
    
    func fetch(fromURL : String ) {
        
//        var urlReq = URLRequest.init(url: URL.init(string: fromURL)!,
//                                        cachePolicy: .reloadRevalidatingCacheData,
//                                        timeoutInterval: 10.0)
//        urlReq.httpMethod = "POST"
//        urlReq.httpBody = "{\"name\":\"test\"}".data(using: .utf8)
//        urlReq.addValue("text/json", forHTTPHeaderField: "Content-Type")
        
        if let url = URL.init(string: fromURL) {
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                // check error, data
                guard error == nil, data != nil else { return }
                print (String.init(data: data!, encoding: .ascii) ?? "no value")
            }
            task.resume()
        }
    }

}

