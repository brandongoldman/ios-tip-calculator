//
//  ViewController.swift
//  LabWebJS
//
//  Created by Bear Q Cahill on 1/22/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    var webView : WKWebView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        defineWebView()
        loadHTML()
    }
    
    func loadHTML() {
        guard let url = Bundle.main.url(forResource: "index", withExtension: "html") else { return }
        guard let html = try? String.init(contentsOf: url) else { return }
        webView?.loadHTMLString(html, baseURL: nil)
    }

    func defineWebView() {
        webView = WKWebView(frame: self.view.bounds)
        self.view.addSubview(webView!)

    }


}

