//
//  ViewController.swift
//  LabWebV
//
//  Created by Bear Q Cahill on 1/17/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController{

    @IBOutlet weak var tvText: UITextView!
    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loadHTML()
    }
    
    func loadHTML() {
        guard let url = Bundle.main.url(forResource: "index", withExtension: "html") else { return }
        guard let html = try? String.init(contentsOf: url) else { return }
        webView.loadHTMLString(html, baseURL: nil)
    }
    
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        print (action)
        webviewGetSelection(webView: self.webView) { (result, error) in
            print (error ?? "no error")
            print (result ?? "no result")
            guard let r = result as? String else { return }
            self.tvText.text = r
        }
        return false
    }

    func webviewGetSelection(webView: WKWebView, completion : @escaping (Any?, Error?)->Void)
    {
        guard let url = Bundle.main.url(forResource: "getSelection", withExtension: "js") else { return }
        guard let js = try? String.init(contentsOf: url) else { return }
        webView.evaluateJavaScript(js) { (result, error) in
            print (result ?? "no result")
            completion(result, error)
        }
    }
    

}

