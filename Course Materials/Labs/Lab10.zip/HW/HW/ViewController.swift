//
//  ViewController.swift
//  HW
//
//  Created by Bear Q Cahill on 12/23/19.
//  Copyright © 2019 Bear Cahill. All rights reserved.
//

import UIKit

class TipCalc {
//    var tipPercentage = 0.15
//
//    init(tp : Double) {
//        tipPercentage = tp
//    }
    
    func calcTip(amount: Double, tipPercentage : Double = 0.15) -> Double {
        return amount * tipPercentage
    }
}

class Person {
    var isDirty = false
    var DOB : Date {
        get {
            return Date.init(timeIntervalSinceNow: -age)
        }
        set {
            age = -newValue.timeIntervalSinceNow
        }
    }
    var age : Double = 0.0 {
        willSet {
            print (newValue)
            isDirty = true
        }
    }
}

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var tfInput: UITextField!
    @IBOutlet weak var lblInfo: UILabel!
    @IBOutlet weak var segTipPercs: UISegmentedControl!
    @IBOutlet weak var btnCalc: UIButton!
    
    var tipPercentage = 0.15
    var tipVals = [0.1, 0.15, 0.2]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblInfo.text = "Hello iOS!"
        
        print (self.view.frame)
        let tc = TipCalc()
        var r = tc.calcTip(amount: 20.0)
        print (r)
        r = tc.calcTip(amount: 20.0, tipPercentage: 0.25)
        print (r)
        // Do any additional setup after loading the view.
        
        let p = Person()
        print (p.DOB)
        p.age = 300
        print (p.DOB)
        p.DOB = Date.init(timeIntervalSinceNow: -600)
        print (p.DOB)
        print (p.age)
        
        for x in 0..<tipVals.count {
            let str = "\(tipVals[x]*100.0)%"
            segTipPercs.setTitle(str, forSegmentAt: x)
        }
        
        configUI()
    }
    
    func configUI() {
        
        lblInfo.backgroundColor = UIColor.lightGray
        btnCalc.backgroundColor = UIColor.lightGray
        // label
        // set the top of the labe to be 43 points below the safe area of the self.vew
        let lblConTop = lblInfo.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 43)
        lblConTop.isActive = true
        
        // set the leading edge to be 44 points in from the leading edge of the self.view safe area
        // created and activated
        NSLayoutConstraint.init(item: lblInfo!, attribute: .leading, relatedBy: .equal, toItem: self.view.safeAreaLayoutGuide, attribute: .leading, multiplier: 1.0, constant: 44)
            .isActive = true
        
        // set the trailing edge to be 44 points in
        let lblConTrailing = NSLayoutConstraint.init(item: lblInfo!, attribute: .trailing, relatedBy: .equal, toItem: self.view.safeAreaLayoutGuide, attribute: .trailing, multiplier: 1.0, constant: -44)
        lblConTrailing.isActive = true
        // setting priority example (not really needed in this case)
        lblConTrailing.priority = UILayoutPriority.init(500)
        
//        self.view.directionalLayoutMargins = NSDirectionalEdgeInsets(top: self.view.directionalLayoutMargins.top,
//                                                                     leading: 10,
//                                                                     bottom: self.view.directionalLayoutMargins.bottom,
//                                                                    trailing: 100)        
        // text field
        let tfCons = [
            // 28 below bottom of label
            tfInput.topAnchor.constraint(equalTo: lblInfo.bottomAnchor, constant: 28),
            tfInput.leadingAnchor.constraint(equalTo: self.view.layoutMarginsGuide.leadingAnchor, constant: 44),
            tfInput.trailingAnchor.constraint(equalTo: self.view.layoutMarginsGuide.trailingAnchor, constant: -44)
        ]
        NSLayoutConstraint.activate(tfCons)
        
        // seg control
        let scCons = [
            segTipPercs.leadingAnchor.constraint(equalTo: tfInput.leadingAnchor),
            segTipPercs.widthAnchor.constraint(equalTo: tfInput.widthAnchor),
            segTipPercs.centerYAnchor.constraint(equalTo: tfInput.centerYAnchor, constant: 60)
        ]
        NSLayoutConstraint.activate(scCons)

        // button
        let btnCons = [
            NSLayoutConstraint.init(item: btnCalc!, attribute: .top, relatedBy: .equal, toItem: segTipPercs, attribute: .bottom, multiplier: 1.0, constant: 80),
            btnCalc.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
//            btnCalc.widthAnchor.constraint(equalToConstant: 100),
            
            
            // half the width of segTipPercs
            btnCalc.widthAnchor.constraint(equalTo: segTipPercs.widthAnchor, multiplier: 0.5)
        ]
        
        btnCalc.setContentHuggingPriority(.defaultHigh, for: .horizontal)
        
        NSLayoutConstraint.activate(btnCons)
    }

    @IBAction func doBtnAction(_ sender: Any) {
        lblInfo.text = tfInput.text
        calcTip()
    }
    
    @IBAction func doSegChange(_ sender: UISegmentedControl) {
        tipPercentage = tipVals[sender.selectedSegmentIndex]
        calcTip()
    }
    
    @IBAction func doTFChg(_ sender: Any) {
        calcTip()
    }
    
    func calcTip() {
        guard let val = tfInput.text else { return }
        guard let amt = Double(val) else { return }
        let tip = TipCalc().calcTip(amount: amt, tipPercentage: tipPercentage)
        lblInfo.text = "Tip: $\(tip)   Total: $\(tip + amt)"
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        lblInfo.text = tfInput.text
        return false
    }
    
}

