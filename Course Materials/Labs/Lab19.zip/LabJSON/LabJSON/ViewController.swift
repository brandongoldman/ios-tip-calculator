//
//  ViewController.swift
//  LabJSON
//
//  Created by Bear Q Cahill on 1/16/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit

struct Music : Codable {
    var id = ""
    var music_url : URL?
    var name = ""
    var description = ""
    var image_url : URL?
    var thumb_url : URL?
    var dirty = false
    
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case music_url = "music_url"
        case name = "name"
        case description = "description"
        case image_url = "image"
        case thumb_url = "thumb"
    }
}

class ViewController: UIViewController {
    
    var items : [Music]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        fetchMusic()
        
//        items = loadMusic()
//        guard let data = encodeToJSON(music: items) else { return }
//        items = decodeJSON(data: data)
//        print (items?.count ?? 0)
    }

    func fetchMusic() {
        let urlString = "https://orangevalleycaa.org/api/music"
        let task = URLSession.shared.dataTask(with: URL(string: urlString)!) { (data, response, error) in
            guard error == nil, let data = data else { return }
            self.items = self.decodeJSON(data: data)
        }
        task.resume()
    }

    // loads JSON using string at bottom of file
    func loadMusic() -> [Music]? {
        guard let data = jsonString.data(using: .utf8) else { return nil }
        return decodeJSON(data: data)
    }
    
    func decodeJSON(data : Data) -> [Music]? {
        let items = try? JSONDecoder().decode([Music].self, from: data)
        return items
    }
    
    func encodeToJSON(music : [Music]?) -> Data? {
        guard let music = music else { return nil }
        guard let data = try? JSONEncoder().encode(music) else { return nil }
        return data
    }

}

let jsonString = """
[{
    "id": "1",
    "music_url": "http://orangevalleycaa.org/api/media/music/ModernHardRock_45450.wav",
    "name": "Modern Hard Rock",
    "description": "Powerful rock track with cool guitar riffs, energetic groovy drums, tight bass and guitar solo. Perfect for use in sport (like boxing) videos, advertisements etc.",
    "duration": "2:18",
    "image": "http://orangevalleycaa.org/api/media/images/ArtistWorking_059730538.png",
    "thumb": "http://orangevalleycaa.org/api/media/images/thumbs/ArtistWorking_059730538.png",
    "created_by": "ikoliks",
    "file_name_original": "Modern hard rock_LYNDA_45450.wav"
}, {
    "id": "2",
    "music_url": "http://orangevalleycaa.org/api/media/music/AcousticIntro_45687.wav",
    "name": "Acoustic Intro",
    "description": "Short acoustic guitar intro with a dreamy, relaxed quality that inspires reflection.",
    "duration": "0:57",
    "image": "http://orangevalleycaa.org/api/media/images/BalletInSmoke_054599628.png",
    "thumb": "http://orangevalleycaa.org/api/media/images/thumbs/BalletInSmoke_054599628.png",
    "created_by": "Trevor Lackey",
    "file_name_original": "Acoustic Intro_LYNDA_45687.wav"
}, {
    "id": "3",
    "music_url": "http://orangevalleycaa.org/api/media/music/OptimisticLife_41224.wav",
    "name": "Optimistic Life",
    "description": "Song with optimistic vibe, that's perfect background for music videos that need an uplifting and cool atmosphere.",
    "duration": "0:30",
    "image": "http://orangevalleycaa.org/api/media/images/BlowingGlass_066874921.png",
    "thumb": "http://orangevalleycaa.org/api/media/images/thumbs/BlowingGlass_066874921.png",
    "created_by": "PremiumAudio",
    "file_name_original": "Optimistic Life_LYNDA_41224.wav"
}, {
    "id": "4",
    "music_url": "http://orangevalleycaa.org/api/media/music/TraceyLarvenz_35879.wav",
    "name": "Light and Oxygen",
    "description": "A bubbly, soothing track suited for corporate, marketing, and motivational videos.",
    "duration": "3:05",
    "image": "http://orangevalleycaa.org/api/media/images/FireDancers_042981315.png",
    "thumb": "http://orangevalleycaa.org/api/media/images/thumbs/FireDancers_042981315.png",
    "created_by": "Tracey Larvenz",
    "file_name_original": "Tracey Larvenz track_LYNDA_35879.wav"
}, {
    "id": "5",
    "music_url": "http://orangevalleycaa.org/api/media/music/ExploreCaliforniaIntro_8773.wav",
    "name": "Exploring California",
    "description": "A synth and percussion track as smooth as a drive along the California coast.",
    "duration": "0:20",
    "image": "http://orangevalleycaa.org/api/media/images/GlassBlownDragon_056473995.png",
    "thumb": "http://orangevalleycaa.org/api/media/images/thumbs/GlassBlownDragon_056473995.png",
    "created_by": "Bryce Poole",
    "file_name_original": "Explore California Intro_LYNDA_8773.wav"
}]
"""
