function f() {
var txt = window.getSelection();
return ("" + txt)
}
f();
