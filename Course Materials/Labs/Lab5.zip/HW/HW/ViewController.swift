//
//  ViewController.swift
//  HW
//
//  Created by Bear Q Cahill on 12/23/19.
//  Copyright © 2019 Bear Cahill. All rights reserved.
//

import UIKit

class TipCalc {
//    var tipPercentage = 0.15
//
//    init(tp : Double) {
//        tipPercentage = tp
//    }
    
    func calcTip(amount: Double, tipPercentage : Double = 0.15) -> Double {
        return amount * tipPercentage
    }
}

class Person {
    var isDirty = false
    var DOB : Date {
        get {
            return Date.init(timeIntervalSinceNow: -age)
        }
        set {
            age = -newValue.timeIntervalSinceNow
        }
    }
    var age : Double = 0.0 {
        willSet {
            print (newValue)
            isDirty = true
        }
    }
}

class ViewController: UIViewController {

    @IBOutlet weak var lblInfo: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblInfo.text = "Hello iOS!"
        
        print (self.view.frame)
        let tc = TipCalc()
        var r = tc.calcTip(amount: 20.0)
        print (r)
        r = tc.calcTip(amount: 20.0, tipPercentage: 0.25)
        print (r)
        // Do any additional setup after loading the view.
        
        let p = Person()
        print (p.DOB)
        p.age = 300
        print (p.DOB)
        p.DOB = Date.init(timeIntervalSinceNow: -600)
        print (p.DOB)
        print (p.age)
    }

    @IBAction func doBtnAction(_ sender: Any) {
        lblInfo.text = "Tapped!"
    }
    
}

