//
//  ViewController.swift
//  LabTableV
//
//  Created by Bear Q Cahill on 1/16/20.
//  Copyright © 2020 Bear Cahill. All rights reserved.
//

import UIKit

class ViewController: UIViewController,
        UITableViewDataSource, UITableViewDelegate {
    
    var items = [String]()
    var refreshControl : UIRefreshControl!
    
    @objc func didActivatePullToRefresh() {
        refreshControl?.endRefreshing()
        // refresh table view
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        for x in 0..<50 {
            items.append("\(x) \(Date())")
        }
    }

    func tableView(_ tableView: UITableView,
        numberOfRowsInSection section: Int) -> Int {
        
        if tableView.refreshControl == nil {
            refreshControl = UIRefreshControl()
            refreshControl.addTarget(self,
                action: #selector(ViewController.didActivatePullToRefresh),
                for: .valueChanged)
            tableView.refreshControl = refreshControl
        }
        
        return items.count
    }
    
    func tableView(_ tableView: UITableView,
        titleForHeaderInSection section: Int) -> String? {
        return "Section \(section)"
    }
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellInfo",
                                                 for: indexPath)
        cell.textLabel?.text = items[indexPath.row]
        cell.detailTextLabel?.text = "\(indexPath)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return indexPath.section == 0 // only section 0 can be edited
    }
    func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt
        indexPath: IndexPath) -> String? {
        return "Destroy"
    }
    func tableView(_ tableView: UITableView, commit
        editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        switch editingStyle {
        case .delete:
            items.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        default:
            print ("something else")
        }
    }

    // iOS 8..<13 (deprecated)
    func tableView(_ tableView: UITableView,
                   editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let actionDelete = UITableViewRowAction.init(style: .destructive,
                                                     title: "Trash") { (action, ip) in
            // delete item
            self.items.remove(at: ip.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
        return [actionDelete]
    }

    // iOS 11+
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let actionSnooze = UIContextualAction.init(style: .normal,
                                                   title: "Snooze")
        { (action, view, handler: (Bool)->Void) in
            // do something
            handler(true)
        }
        actionSnooze.image = UIImage.init(named: "snooze.png")
        let config = UISwipeActionsConfiguration.init(actions: [actionSnooze])
        return config
    }


}

